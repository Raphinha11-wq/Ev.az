<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $users = json_decode(file_get_contents("users.json"), true);
    $username = $_POST["username"];
    $password = $_POST["password"];
    if (isset($users[$username]) && password_verify($password, $users[$username]["password"])) {
        $_SESSION["username"] = $username;
        header("Location: index.php");
        exit();
    } else {
        $error = "Yanlış istifadəçi adı və ya şifrə";
    }
}
?>
<!DOCTYPE html>
<html lang="az">
<head><meta charset="UTF-8"><title>Daxil ol</title></head>
<body>
<h2>Daxil ol</h2>
<?php if (!empty($error)) echo "<p style='color:red;'>$error</p>"; ?>
<form method="post">
    İstifadəçi adı: <input type="text" name="username" required><br>
    Şifrə: <input type="password" name="password" required><br>
    <input type="submit" value="Daxil ol">
</form>
<a href="register.php">Qeydiyyat</a>
</body>
</html>
