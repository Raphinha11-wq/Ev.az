<?php
session_start();
if (!isset($_SESSION["username"])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="az">
<head>
    <meta charset="UTF-8">
    <title>Ev.az - Əsas səhifə</title>
</head>
<body>
    <h1>Xoş gəlmisiniz, <?php echo $_SESSION["username"]; ?>!</h1>
    <p><a href="add_listing.php">Elan əlavə et</a></p>
    <p><a href="logout.php">Çıxış</a></p>
</body>
</html>
