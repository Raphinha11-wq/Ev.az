<?php
session_start();
if (!isset($_SESSION["username"])) {
    header("Location: login.php");
    exit();
}
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $listings = json_decode(file_get_contents("listings.json"), true);
    $listings[] = [
        "user" => $_SESSION["username"],
        "title" => $_POST["title"],
        "type" => $_POST["type"],
        "vip" => isset($_POST["vip"]) ? true : false,
        "premium" => isset($_POST["premium"]) ? true : false
    ];
    file_put_contents("listings.json", json_encode($listings, JSON_PRETTY_PRINT));
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="az">
<head><meta charset="UTF-8"><title>Elan əlavə et</title></head>
<body>
<h2>Elan əlavə et</h2>
<form method="post">
    Başlıq: <input type="text" name="title" required><br>
    Növ: 
    <select name="type">
        <option value="satış">Satış</option>
        <option value="icarə">İcarə</option>
    </select><br>
    VIP (+5 AZN): <input type="checkbox" name="vip"><br>
    Premium (+10 AZN): <input type="checkbox" name="premium"><br>
    <input type="submit" value="Elan yerləşdir">
</form>
<a href="index.php">Geri</a>
</body>
</html>
