<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $users = json_decode(file_get_contents("users.json"), true);
    $username = $_POST["username"];
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT);
    $users[$username] = ["password" => $password];
    file_put_contents("users.json", json_encode($users, JSON_PRETTY_PRINT));
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="az">
<head><meta charset="UTF-8"><title>Qeydiyyat</title></head>
<body>
<h2>Qeydiyyat</h2>
<form method="post">
    İstifadəçi adı: <input type="text" name="username" required><br>
    Şifrə: <input type="password" name="password" required><br>
    <input type="submit" value="Qeydiyyatdan keç">
</form>
<a href="login.php">Daxil ol</a>
</body>
</html>
